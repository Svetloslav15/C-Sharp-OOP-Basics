﻿using System.Collections.Generic;

public interface INation
{
    ICollection<Bender> nation { get; }
}