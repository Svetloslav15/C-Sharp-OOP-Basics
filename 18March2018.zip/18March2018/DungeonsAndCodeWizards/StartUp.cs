﻿using DungeonsAndCodeWizards.Core;

namespace DungeonsAndCodeWizards
{
	public class StartUp
	{
		public static void Main(string[] args)
		{
            Engine engine = new Engine();
            engine.Run();
		}
	}
}