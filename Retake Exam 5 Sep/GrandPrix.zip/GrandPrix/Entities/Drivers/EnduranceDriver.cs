﻿public class EnduranceDriver : Driver
{
    public EnduranceDriver(string name, double totalTime, Car car)
        : base(name, car, 1.5)
    {
    }
}