﻿namespace DungeonsAndCodeWizards.Entities.Characters.Interfaces
{
    public interface IHealable
    {
        void Heal(Character character);
    }
}
