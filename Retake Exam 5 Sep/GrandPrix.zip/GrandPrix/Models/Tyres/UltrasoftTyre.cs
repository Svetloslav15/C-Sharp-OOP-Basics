﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GrandPrix.Models.Tyres
{
    public class UltrasoftTyre : Tyre
    {
        public double Grip { get; set; }

        protected UltrasoftTyre(double hardness)
            : base("Ultrasoft", hardness)
        {
        }
        public override void CompleteLab()
        {
            base.CompleteLab();
            this.Degradation -= this.Grip;
            if (this.Degradation < 30)
            {
                throw new ArgumentException(ErrorMessages.BlownTyre);
            }
        }
    }
}
