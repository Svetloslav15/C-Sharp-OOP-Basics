﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses.Models.Food
{
    public class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
