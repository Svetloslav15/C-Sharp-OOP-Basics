﻿namespace DungeonsAndCodeWizards.Entities.Characters.Interfaces
{
    public interface IAttackable
    {
        void Attack(Character character);
    }
}
