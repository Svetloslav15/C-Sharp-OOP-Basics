﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GrandPrix.Models.Drivers
{
    public abstract class Driver
    {
        public string Name { get; }
        public Car Car { get; set; }
        public double FuelConsumptionPerKm { get; set; }
        public virtual double Speed => (this.Car.Hp + this.Car.Tyre.Degradation) / this.Car.FuelAmount;
        public double TotalTime = 0.0;

        protected Driver(string name, Car car, double fuelConsumptionPerKm)
        {
            this.Name = name;
            this.Car = car;
            this.FuelConsumptionPerKm = fuelConsumptionPerKm;
        }
    }
}
