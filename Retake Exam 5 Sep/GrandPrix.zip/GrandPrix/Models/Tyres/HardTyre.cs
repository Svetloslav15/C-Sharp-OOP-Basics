﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GrandPrix.Models.Tyres
{
    public class HardTyre : Tyre
    {
        protected HardTyre(double hardness) 
            : base("Hard", hardness)
        {
        }
    }
}