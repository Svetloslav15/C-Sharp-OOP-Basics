﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses.Models.Food
{
    public class Fruit : Food
    {
        public Fruit(int quantity) : base(quantity)
        {
        }
    }
}
