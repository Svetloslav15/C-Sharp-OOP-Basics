﻿using System;

namespace BankAccount
{
    class StartUp
    {
        static void Main(string[] args)
        {
           
        }
    }
}
