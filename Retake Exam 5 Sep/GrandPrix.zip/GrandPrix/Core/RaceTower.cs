﻿using System.Collections.Generic;

public class RaceTower
{
    public void SetTrackInfo(int lapsNumber, int trackLength)
    {
        
    }
    public void RegisterDriver(List<string> commandArgs)
    {
        
    }

    public void DriverBoxes(List<string> commandArgs)
    {
        
    }

    public string CompleteLaps(List<string> commandArgs)
    {
        return "";
    }

    public string GetLeaderboard()
    {
        return "";
    }

    public void ChangeWeather(List<string> commandArgs)
    {
       
    }

}