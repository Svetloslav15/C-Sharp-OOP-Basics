﻿namespace MilitaryElite.Interfaces
{
    public interface ISpy
    {
        int CodeNumber { get; }
    }
}