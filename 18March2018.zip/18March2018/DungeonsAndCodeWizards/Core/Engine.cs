﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DungeonsAndCodeWizards.Core
{
    public class Engine
    {
        private DungeonMaster dungeonMaster;
        public Engine()
        {
            this.dungeonMaster = new DungeonMaster();
        }
        public void Run()
        {
            try
            {
                while (!this.dungeonMaster.IsGameOver())
                {
                    string[] tokens = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                    string command = tokens[0];
                    switch (command)
                    {
                        case "JoinParty":
                            Print(dungeonMaster.JoinParty(tokens.Skip(1).ToArray())); break;
                        case "AddItemToPool":
                            Print(dungeonMaster.AddItemToPool(tokens.Skip(1).ToArray())); break;
                        case "PickUpItem":
                            Print(dungeonMaster.PickUpItem(tokens.Skip(1).ToArray())); break;
                        case "UseItem":
                            Print(dungeonMaster.UseItem(tokens.Skip(1).ToArray())); break;
                        case "UseItemOn":
                            Print(dungeonMaster.UseItemOn(tokens.Skip(1).ToArray())); break;
                        case "GiveCharacterItem":
                            Print(dungeonMaster.GiveCharacterItem(tokens.Skip(1).ToArray())); break;
                        case "GetStats":
                            Print(dungeonMaster.GetStats()); break;
                        case "Attack":
                            Print(dungeonMaster.Attack(tokens.Skip(1).ToArray())); break;
                        case "Heal":
                            Print(dungeonMaster.Heal(tokens.Skip(1).ToArray())); break;
                        case "EndTurn":
                            Print(dungeonMaster.EndTurn(tokens.Skip(1).ToArray())); break;
                        case "IsGameOver":
                            {
                                if (dungeonMaster.IsGameOver())
                                {
                                    GameStats(dungeonMaster);
                                    GameOver();
                                }
                            }break;
                        default:
                            break;
                    }
                }
            }
            catch (ArgumentException error)
            {
                Console.WriteLine($"Parameter Error: {error.Message}");
            }
            catch(InvalidOperationException error)
            {
                Console.WriteLine($"Invalid Operation: {error.Message}");
            }
        }
        private static void Print(string text)
        {
            Console.WriteLine(text);
        }
        static void GameOver()
        {
            Environment.Exit(0);
        }

        static void GameStats(DungeonMaster game)
        {
            Print("Final stats:");
            Print(game.GetStats());
        }
    }
}
