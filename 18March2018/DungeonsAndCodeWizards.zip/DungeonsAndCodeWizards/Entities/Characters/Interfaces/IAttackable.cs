﻿using DungeonsAndCodeWizards.Characters;
using System;
using System.Collections.Generic;
using System.Text;

namespace DungeonsAndCodeWizards.Entities.Characters.Interfaces
{
    public interface IAttackable
    {
        void Attack(Character character);
    }
}
