﻿using System;

namespace GrandPrix
{
    public class StartUp
    {
        static void Main()
        {

        }
    }
}